package com.moj.nested.page;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.moj.nested.R;


/**
 * @Author yangsanning
 * @ClassName AvatarActivity
 * @Description 头像随动
 * @Date 2020/4/30
 */
public class AvatarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar);
    }
}